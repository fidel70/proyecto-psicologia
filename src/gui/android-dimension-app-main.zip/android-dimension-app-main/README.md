# android-dimension-app
Apliación para registro de dimensiones de pensamientos para un paciente
